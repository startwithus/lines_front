
import betLoader from '../assets/loader.96576605.svg'
export const svgIcon={
betloader:betLoader,
infoIcon:<svg xmlns="http://www.w3.org/2000/svg" width="10" height="10" fill="none" viewBox="0 0 18 18"><path fill="currentColor" fillRule="evenodd" d="M18 9A9 9 0 1 0 0 9a9 9 0 0 0 18 0Zm-16.506.036a7.51 7.51 0 1 1 15.019 0 7.51 7.51 0 0 1-15.019 0ZM8 12.9a.9.9 0 1 1 1.8 0v.394a.9.9 0 0 1-1.8 0V12.9ZM8.902 4A.902.902 0 0 0 8 4.902v5.66a.902.902 0 0 0 1.804 0v-5.66A.902.902 0 0 0 8.902 4Z" clipRule="evenodd"></path></svg>,


}