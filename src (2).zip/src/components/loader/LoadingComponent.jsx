import React from 'react'
import '../loader/loader.css'
const LoadingComponent = () => {
  return (

      <div className="loader-1"></div>

  )
}

export default LoadingComponent