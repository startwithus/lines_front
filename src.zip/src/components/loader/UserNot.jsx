import React from 'react'


const UserNot = () => {
  return (
    <div className="overlay">
    <div className="modal-socket">
      <div className="">
        <div className="">
          <p className="please-check">Please Login Through Valid Source</p>
          <span className="please-para">User does not exist</span>
        </div>
      </div>
    </div>
  </div>
  )
}

export default UserNot