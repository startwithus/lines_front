import React, { useEffect, useState } from "react";
import { icon } from "../../utility/icon";
import LinerAnimation from "./LinerAnimation";
import { calculateMultiplier } from "../../utility/helper";

const MultiplierProgress = ({
  setAutoMultiplier,
  currentMax,
  isBetting,
  sliderValue1,
  setSliderValue1,
  resultData,
  mappedMultiplier,
}) => {
  const [sliderValue, setSliderValue] = useState(11);
  const [isActive, setIsActive] = useState(false);
  const [iconToDisplay, setIconToDisplay] = useState(icon.groupA);
  const [sliders, setSliders] = useState([sliderValue]); // Store up to 3 sliders
  const [autoMultipliers, setAutoMultipliers] = useState(["2.07x"]); // Store multipliers for sliders

  const handleMouseDown = () => setIsActive(true);
  const handleMouseUp = () => setIsActive(false);

  // Change the image based on the condition of sliderValue1 and autoMultiplier
  useEffect(() => {
    if (isBetting) {
      setIconToDisplay(icon.groupA); // Reset to groupA when betting starts
    } else {
      if (sliderValue1 > parseFloat(autoMultipliers[0])) {
        setIconToDisplay(icon.group3); // Show group3 if sliderValue1 > autoMultiplier
      } else if (sliderValue1 < parseFloat(autoMultipliers[0])) {
        setIconToDisplay(icon.group2); // Show group2 if sliderValue1 < autoMultiplier
      } else {
        setIconToDisplay(icon.groupA);
      }
    }
  }, [sliderValue1, autoMultipliers, isBetting]);

  const handleSliderChange = (index, e) => {
    const newValue = parseFloat(e.target.value);
    const updatedSliders = [...sliders];
    const updatedMultipliers = [...autoMultipliers];

    updatedSliders[index] = newValue;
    updatedMultipliers[index] = calculateMultiplier(newValue).toFixed(2) + "x";

    setSliders(updatedSliders);
    setAutoMultipliers(updatedMultipliers);

    // Optionally set the first autoMultiplier globally
    if (index === 0) {
      setAutoMultiplier(updatedMultipliers[0]);
    }
  };

  const handleAddSlider = () => {
    if (sliders.length < 3) {
      setSliders([...sliders, sliderValue]);
      setAutoMultipliers([
        ...autoMultipliers,
        calculateMultiplier(sliderValue).toFixed(2) + "x",
      ]);
    }
  };

  const handleRemoveSlider = (index) => {
    if (index !== 0) {
      const updatedSliders = sliders.filter((_, i) => i !== index);
      const updatedMultipliers = autoMultipliers.filter((_, i) => i !== index);

      setSliders(updatedSliders);
      setAutoMultipliers(updatedMultipliers);
    }
  };

  return (
    <div className="slider-wrapper">
      <div className="lines-container">
        <img src={icon.line} alt="" />
      </div>
      <div className="current-value-progress">
        <span className="multi-img">
          <img src={iconToDisplay} alt="" />
        </span>
        {/* {/ Display all multipliers /} */}
        {autoMultipliers.map((multiplier, index) => (
          <p className="xvalue" key={index}>
            {multiplier}
          </p>
        ))}
      </div>

      {/* {/ Render sliders /} */}
      {sliders.map((value, index) => (
        <div key={index} style={{ width: "100%", position: "relative" }}>
          <div className="slider-scale">
            <span>1</span>
            <span>25</span>
            <span>50</span>
            <span>75</span>
            <span>100</span>
          </div>
          <div className="tringle-container">
            <div className="triangle-up"></div>
            <div className="triangle-up1"></div>
            <div className="triangle-up2"></div>
            <div className="triangle-up3"></div>
            <div className="triangle-up4"></div>
          </div>
          <div style={{ border: ".5rem solid #fff", borderRadius: ".5rem" }}>
            <div
              style={{
                border: ".2rem solid black",
                borderRadius: "3px",
                position: "relative",
              }}
            >
              <div
                className="slider-track"
                style={{
                  background: `linear-gradient(to right, red ${value}%, #4ace4a ${value}%)`,
                  height: "12px",
                }}
              >
                <div
                  className="white-bg"
                  style={{
                    position: "absolute",
                    top: "-4px",
                    background: "#fff",
                    width: `${sliderValue1}%`, // Set width dynamically based on sliderValue1
                    height: "20px",
                    transition: "width 0.3s ease", // Smooth transition for width change
                  }}
                >
                  <div
                    style={{
                      position: "absolute",
                      top: "50%",
                      right: 0,
                      transform: "translate(50%, -50%)", // Center text vertically and horizontally
                      fontSize: "12px",

                      fontWeight: "700",
                    }}
                  >
                    {sliderValue1 <= 1
                      ? "2" // Show minimum value if it's <= 2
                      : sliderValue1 >= 98
                      ? "98" // Show maximum value if it's >= 98
                      : `${sliderValue1}`}{" "}
                    {/* Show the current value */}
                  </div>
                </div>

                <input
                  type="range"
                  min="1"
                  max="100"
                  value={value}
                  onChange={(e) => handleSliderChange(index, e)}
                  className="slider"
                  onMouseDown={handleMouseDown}
                  onMouseUp={handleMouseUp}
                  style={{
                    position: "absolute",
                    top: "0",
                    left: "0",
                    background: "transparent",
                  }}
                />
              </div>
              <img
                src={isActive ? icon.scrollBar : icon.misc}
                alt="Slider Thumb"
                className="slider-thumb"
                style={{
                  position: "absolute",
                  top: "-6px",
                  left: `calc(${value}% - 10px)`,
                  width: "30px",
                  height: "24px",
                  pointerEvents: "none",
                }}
              />
            </div>
          </div>
          <div
            className="value-display"
            style={{
              left: `calc(${value}% - 170px)`,
              marginTop: "2px",
            }}
          >
            <div>
              {value <= 2 ? "2(MIN)" : value >= 98 ? "98(MAX)" : `${value}`}
            </div>
          </div>

          {/* {/ Close button /} */}
          {index !== 0 && (
            <div
              className="close-slider"
              onClick={() => handleRemoveSlider(index)}
              style={{
                position: "absolute",
                top: "5px",
                left: "5px",
                cursor: "pointer",
              }}
            >
              <div className="crossIcon" style={{ width: "40px" }}>
                <img src={icon.crossIcon} alt="Close" />
              </div>
            </div>
          )}
        </div>
      ))}

      {/* {/ Add Slider /} */}
      {sliders.length < 3 && (
        <div className="plus-section" onClick={handleAddSlider}>
          <h1>ADD LINE</h1>
          <img alt="" src={icon.misc7} />
        </div>
      )}
    </div>
  );
};

export default MultiplierProgress;
