import liner from "../assests/image_2025_01_08T13_38_07_201Z.png";
import linerTwo from "../assests/image_2025_01_08T13_38_07_192Z.png";
import linerThree from "../assests/image_2025_01_08T13_38_07_204Z.png";
import maxMulti from "../assests/image_2025_01_08T13_38_07_208Z.png";
import minMulti from "../assests/image_2025_01_08T13_38_07_209Z.png";
import line from "../assests/misc-5.png";
import buttonNum from "../assests/Group 1.png";
import downIcon from "../assests/Polygon 1.png";
import upIcon from "../assests/Polygon 2.png";
import soundIcon from "../assests/image 5.png";
import unSoundIcon from "../assests/image 6.png";
import muteIcon from "../assests/image 7.png";
import unmuteIcon from "../assests/image 8.png";
import infoIcon from "../assests/image 11.png";
import groupA from "../assests/Group 1.png";
import scrollBar from "../assests/misc-9.png";
import misc from "../assests/misc-8.png";
import misc7 from "../assests/misc-7.png";
import betLoader from "../assests/loader.96576605.svg";
import group3 from "../assests/Group 3.png";
import group2 from "../assests/Group 2.png";
import crossIcon from "../assests/misc-6.png";
import turboIcon from "../assests/image 9.png";
import unknownTurbo from "../assests/image 10.png";
import homeIcon from "../assests/home.png";
export const icon = {
  liner: liner,
  linerTwo: linerTwo,
  linerThree: linerThree,
  maxMulti: maxMulti,
  minMulti: minMulti,
  line: line,
  buttonNum: buttonNum,
  downIcon: downIcon,
  upIcon: upIcon,
  soundIcon: soundIcon,
  unSoundIcon: unSoundIcon,
  muteIcon: muteIcon,
  unmuteIcon: unmuteIcon,
  infoIcon: infoIcon,
  groupA: groupA,
  scrollBar: scrollBar,
  misc: misc,
  misc7: misc7,
  betLoader: betLoader,
  group3: group3,
  group2: group2,
  crossIcon: crossIcon,
  turboIcon: turboIcon,
  unknownTurbo: unknownTurbo,
  homeIcon: homeIcon,
};
